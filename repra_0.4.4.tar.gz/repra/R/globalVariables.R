globalVariables(c(".", "EUE", "BaseEUE", "LOLP",
  "Capacity", "Capacity2", "WinProb", "LOLE", "LOLH",
  "mult", "ELCC", "value", "Day", "Time", "RoundedCapacity", 
  "EFOR", "Level", "Area", "Prob", "Value", "CVTech",
  "Multiplier", "Objective", "ActualObj", "ErrorObj", "Load"))
